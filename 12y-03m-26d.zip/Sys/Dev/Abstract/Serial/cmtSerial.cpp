//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================

uint_8 
CmtSerial::ReadByte( uint8 *dest, uint32* pBreak ) {
  *dest = GetByte();
  return CMTE_OK;
  }

uint_8 
CmtSerial::WriteByte( uint8 byte, uint32* pBreak ) {
  PutByte( byte );
  return CMTE_OK;
  }

uint_8 
CmtSerial::WriteBlock( cpvoid src, uint32 count, uint32* pBreak ) {
  uint_8 res;
  const uint8 *ptr = (uint8*)src;
  while( count-- ) {
    res = WriteByte( *ptr++, pBreak );
    if( res != CMTE_OK ) return res;
    }
  return CMTE_OK;
  }

uint_8 
CmtSerial::ReadBlock( pvoid dest, uint32 count, uint32* pBreak ) {
  uint_8 res;
  uint8 *ptr = (uint8*)dest;
  while( count-- ) {
    res = ReadByte( ptr++, pBreak );
    if( res != CMTE_OK ) return res;
    }
  return CMTE_OK;
  }


