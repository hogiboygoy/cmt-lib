//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================

uint_8 
CmtSpiBase::ReadByte( uint8 *dest, uint32* pBreak ) {
  return Transfer( 0, dest, pBreak );
  }
  
uint_8 
CmtSpiBase::WriteByte( uint8 byte, uint32* pBreak ) {
  return Transfer( byte, &byte, pBreak );
  }  


//���������� ����������
#ifdef CMT_STM32F105VCT6
  #include <SPI/cmtSTM32F105.cpp>
#endif

#ifdef CMT_STM32F103CBT6
  #include <Sys/Dev/Abstract/Spi/cmtSTM32F10x.cpp>
  #include <Sys/Dev/Abstract/Spi/cmtSTM32F103.cpp>
#endif

#ifdef CMT_TI_OMAP3530
  #include <Sys/Dev/Abstract/Spi/cmtTiOmap3530.cpp>
#endif
