//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================
#if defined(CMT_TI_OMAP3530)
  #include <Sys/Dev/Abstract/Sd/cmtSdTiOmap3530.cpp>
#else
  #error "CMT: Not released for this CPU"
#endif


