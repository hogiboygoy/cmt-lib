//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================

//-----------------------------------------------------------------------------
// DSS Devices
//
#define CM_CLKEN_DSS_MASK                   (0x3)
#define CM_CLKEN_DSS1                       (1 << 0)
#define CM_CLKEN_DSS2                       (1 << 1)
#define CM_CLKEN_TV                         (1 << 2)
#define CM_CLKEN_DSS                        (1 << 0)

#define CM_IDLEST_ST_DSS                    (1 << 0)    // ES1.0
#define CM_IDLEST_ST_DSS_IDLE               (1 << 1)    // ES2.0
#define CM_IDLEST_ST_DSS_STDBY              (1 << 0)    // ES2.0

#define CLKSEL_TV_MASK                      (0x1F << 8)
#define CLKSEL_TV(x)                        (((0x1F) & x) << 8)

#define CLKSEL_DSS1_MASK                    (0x1F)
#define CLKSEL_DSS1(x)                      ((0x1F) & x)

//------------------------------------------------------------------------------
//
//  Define: BSP_CM_CLKSEL_DSS
//
//  Determines EMU clock settings.  Used to update CM_CLKSEL_DSS
//
//  Allowed values: BSP_DSS_CLKSEL_DSS1 minimum value is 5 (173 MHz) at nominal voltage
//                  BSP_DSS_CLKSEL_DSS1 minimum value is 9 (96 MHz) at low voltage
//                  BSP_DSS_CLKSEL_TV should be fixed at 16 (54 MHz)
//
//  Note: DPLL4 is 864Mhz
#define BSP_DSS_CLKSEL_DSS1 (11 << 0)    //lcd_res_params[g_dwSelectedDSSResolution].dss1ClkSel
#define BSP_LCD_PIXCLKDIV           2    //lcd_res_params[g_dwSelectedDSSResolution].pixelClkDiv
#define BSP_DSS_CLKSEL_TV   (16 << 8)    // DPLL4/16=54Mhz
#define BSP_CM_CLKSEL_DSS   (BSP_DSS_CLKSEL_TV | \
                             BSP_DSS_CLKSEL_DSS1)

#define DEFAULT_PIXELTYPE   DISPC_PIXELFORMAT_RGB16 //lcd_res_params[g_dwSelectedDSSResolution].pixelFmt

//#define LCD_WIDTH           800 //lcd_res_params[g_dwSelectedDSSResolution].width
//#define LCD_HEIGHT          480 //lcd_res_params[g_dwSelectedDSSResolution].height

#define LCD_HSW             55  //lcd_res_params[g_dwSelectedDSSResolution].hsw
#define LCD_HFP             31  //lcd_res_params[g_dwSelectedDSSResolution].hfp
#define LCD_HBP             135 //lcd_res_params[g_dwSelectedDSSResolution].hbp

#define LCD_VSW             2   //lcd_res_params[g_dwSelectedDSSResolution].vsw
#define LCD_VFP             70  //lcd_res_params[g_dwSelectedDSSResolution].vfp
#define LCD_VBP             68  //lcd_res_params[g_dwSelectedDSSResolution].vbp

#define LCD_LOGCLKDIV       1   //lcd_res_params[g_dwSelectedDSSResolution].logClkDiv
#define LCD_PIXCLKDIV       2   //lcd_res_params[g_dwSelectedDSSResolution].pixelClkDiv

#define LCD_LOADMODE        0 //lcd_res_params[g_dwSelectedDSSResolution].loadMode

#define LCD_POLFREQ         DISPC_POL_FREQ_ONOFF //lcd_res_params[g_dwSelectedDSSResolution].polFreq

#define LCD_DEFAULT_COLOR   0   //lcd_res_params[g_dwSelectedDSSResolution].lcdDefaultColor
#define LCD_TRANS_COLOR     0   //lcd_res_params[g_dwSelectedDSSResolution].lcdTransColor

#define TV_DEFAULT_COLOR    0   //lcd_res_params[g_dwSelectedDSSResolution].tvDefaultColor
#define TV_TRANS_COLOR      0   //lcd_res_params[g_dwSelectedDSSResolution].tvTransColor

#define BSP_LCD_CONFIG              (DISPC_CONFIG_FUNCGATED | DISPC_CONFIG_LOADMODE(2))

#define BSP_GFX_ATTRIBUTES          (DISPC_GFX_ATTR_GFXENABLE | DISPC_GFX_ATTR_GFXFORMAT(DISPC_PIXELFORMAT_RGB32))           // RGB24 unpacked, enabled

#define BSP_GFX_FIFO_THRESHOLD      (DISPC_GFX_FIFO_THRESHOLD_LOW(192) | DISPC_GFX_FIFO_THRESHOLD_HIGH(252))
#define BSP_GFX_ROW_INC             0x00000001
#define BSP_GFX_PIXEL_INC           0x00000001
#define BSP_GFX_WINDOW_SKIP         0x00000000

#if 0
DISPC_PIXELFORMAT_RGB16,            //pixelFmt;
800,                                //width;
480,                                //height;
55,                                 //hsw;
31,                                 //hfp;
135,                                //hbp;
2,                                  //vsw;
70,                                 //vfp;
68,                                 //vbp;
1 ,                                 //logClkDiv;
2,                                  //pixelClkDiv;
(11 << 0),                          //dss1ClkSel;    
0,                                  //loadMode;
DISPC_POL_FREQ_ONOFF,               //polFreq;
0x00000000,                         //lcdDefaultColor;
0x00000000,                         //lcdTransColor;
0x00000000,                         //tvDefaultColor;
0x00000000,                         //tvTransColor;    
#endif

CmtScreenTiOmap3530::CmtScreenTiOmap3530(CmtPoint size, uint32 *src, uint32 *dublBuf) :
  CmtContextTiOmap3530( size, src ),
  mDublBuf(dublBuf) {}

void
CmtScreenTiOmap3530::FrameComplete() {
  if( mDublBuf ) {
    //���������� ����� ������
    //���������� ��� ����������� ������ ���������
    __raw_writel( (uint32)(GetData()), DISPC_GFX_BA0 );
    
    //��������� ��������� (��������� ������ ������ �����������)
    __raw_setl( DISPC_CONTROL_GOLCD, DISPC_CONTROL );
    
    uint32 *tmp = mData;
    mData = mDublBuf;
    mDublBuf = tmp;
    }
  }

void
CmtScreenTiOmap3530::Init() {
  ResetDisplayController();

  // Enable LCD clocks
  EnableLcdPower();

  // Configure the DSS registers
  ConfigureDss( (uint32)mData );
    
  // Display data on LCD
  DisplayLcdImage();
  }

void
CmtScreenTiOmap3530::SetMode( int mode ) {
  }

//void
//CmtScreenTiOmap3530::CopyFull( CmtContext *src ) {
//  __raw_writel( MBIT7, DISPC_IRQSTATUS );
//  }

void 
CmtScreenTiOmap3530::WaitEndOfFrame() {
  //�������� ��� ����� ��������� ������������ ������
  __raw_writel( MBIT7, DISPC_IRQSTATUS );
  //������� ��������� ���� ��������� ������������ ������
  cmtWaitBreakSetBit( DISPC_IRQSTATUS, MBIT7, 0 );
  }


void 
CmtScreenTiOmap3530::ResetDisplayController() {
  // enable all display clocks
  uint32 fclk = __raw_readl(CM_FCLKEN_DSS);
  uint32 iclk = __raw_readl(CM_ICLKEN_DSS);

  __raw_writel( (fclk | CM_CLKEN_DSS1 | CM_CLKEN_DSS2 | CM_CLKEN_TV), CM_FCLKEN_DSS );
  __raw_writel( (iclk | CM_CLKEN_DSS), CM_ICLKEN_DSS );
  
  // disable the display controller
  //disable_dss();

  // reset the display controller
  __raw_writel( DISPC_SYSCONFIG_SOFTRESET, DISPC_SYSCONFIG );
  
  // wait until reset completes OR timeout occurs
  while( !(__raw_readl(DISPC_SYSSTATUS) & DISPC_SYSSTATUS_RESETDONE) );

  uint32 reg_val = __raw_readl( DISPC_SYSCONFIG );
  reg_val &=~(DISPC_SYSCONFIG_SOFTRESET);
  __raw_writel( reg_val, DISPC_SYSCONFIG );

  // restore old clock settings
  __raw_writel( fclk, CM_FCLKEN_DSS );
  __raw_writel( iclk, CM_ICLKEN_DSS );
  
  }

void 
CmtScreenTiOmap3530::EnableLcdPower() {
  __raw_setl( (CM_CLKEN_DSS1 | CM_CLKEN_DSS2), CM_FCLKEN_DSS );
  __raw_setl( (CM_CLKEN_DSS), CM_ICLKEN_DSS );
  }

void 
CmtScreenTiOmap3530::ConfigureDss( uint32 frameBuffer ) {
  
  //  Configure the clock source
  __raw_writel( DSS_CONTROL_DISPC_CLK_SWITCH_DSS1_ALWON |
                DSS_CONTROL_DSI_CLK_SWITCH_DSS1_ALWON,
                DSS_CONTROL );
  
  //  Configure interconnect parameters
  __raw_writel( DISPC_SYSCONFIG_AUTOIDLE, DSS_SYSCONFIG );
  __raw_writel( DISPC_SYSCONFIG_AUTOIDLE|SYSCONFIG_NOIDLE|SYSCONFIG_NOSTANDBY, DISPC_SYSCONFIG );

  // Not enabling any interrupts
  __raw_writel( 0x00000000, DISPC_IRQENABLE );
  
  //  Configure the LCD
  LdcInitialise();
     
  //  Over-ride default LCD config
  __raw_writel( BSP_LCD_CONFIG, DISPC_CONFIG );
  
  
  // Configure Graphics Window
  //--------------------------
  
  __raw_writel( frameBuffer, DISPC_GFX_BA0 );
  __raw_writel( frameBuffer, DISPC_GFX_BA1 );

  // configure the position of graphics window
  __raw_writel( 0, DISPC_GFX_POSITION );
  
  // size of graphics window
  __raw_writel( (mSize.x - 1) | ((mSize.y - 1) << 16), DISPC_GFX_SIZE );
  
  // GW Enabled, RGB24 packed, Little Endian
  __raw_writel( BSP_GFX_ATTRIBUTES, DISPC_GFX_ATTRIBUTES );
  
  __raw_writel( BSP_GFX_FIFO_THRESHOLD, DISPC_GFX_FIFO_THRESHOLD );
  __raw_writel( BSP_GFX_ROW_INC, DISPC_GFX_ROW_INC );
  __raw_writel( BSP_GFX_PIXEL_INC, DISPC_GFX_PIXEL_INC );
  __raw_writel( BSP_GFX_WINDOW_SKIP, DISPC_GFX_WINDOW_SKIP );
  }

void 
CmtScreenTiOmap3530::LdcInitialise() {
  
  // Initialize GPIO
  MUX_VAL( CP(HDQ_SIO), (IDIS|PTD|DIS|M4) );
  //���������� ��� ������� �����
  GPIO_Direction( GPIO6_BASE, MBIT10, false );
  
  // setup the DSS1 clock divider - disable DSS1 clock, change divider, enable DSS clock
  __raw_clearl( CM_CLKEN_DSS1, CM_FCLKEN_DSS );
  __raw_writel( BSP_DSS_CLKSEL_DSS1, CM_CLKSEL_DSS );
  __raw_writel( __raw_readl(CM_FCLKEN_DSS) | CM_CLKEN_DSS1, CM_FCLKEN_DSS );
  
  //  LCD control
  __raw_writel( DISPC_CONTROL_GPOUT1 |
                DISPC_CONTROL_GPOUT0 |
                DISPC_CONTROL_TFTDATALINES_24 |
                DISPC_CONTROL_STNTFT,
                DISPC_CONTROL );
              
  //  LCD config
  __raw_writel( DISPC_CONFIG_FUNCGATED |
                DISPC_CONFIG_LOADMODE(LCD_LOADMODE) |
                DISPC_CONFIG_PALETTEGAMMATABLE,
                DISPC_CONFIG );

  // Default Color
  __raw_writel( LCD_DEFAULT_COLOR, DISPC_DEFAULT_COLOR0 );

  // Default Transparency Color
  __raw_writel( LCD_TRANS_COLOR, DISPC_TRANS_COLOR0 );

  // Timing logic for HSYNC signal
  __raw_writel( DISPC_TIMING_H_HSW(LCD_HSW) |
                DISPC_TIMING_H_HFP(LCD_HFP) |
                DISPC_TIMING_H_HBP(LCD_HBP),
                DISPC_TIMING_H );

  // Timing logic for VSYNC signal
  __raw_writel( DISPC_TIMING_V_VSW(LCD_VSW) |
                DISPC_TIMING_V_VFP(LCD_VFP) |
                DISPC_TIMING_V_VBP(LCD_VBP),
                DISPC_TIMING_V );

  // Signal configuration
  __raw_writel( LCD_POLFREQ, DISPC_POL_FREQ );

  // Configures the divisor
  __raw_writel( DISPC_DIVISOR_PCD(LCD_PIXCLKDIV) |
                DISPC_DIVISOR_LCD(LCD_LOGCLKDIV),
                DISPC_DIVISOR );
  
  // Configures the panel size
  __raw_writel( DISPC_SIZE_LCD_LPP(mSize.y) |
                DISPC_SIZE_LCD_PPL(mSize.x),
                DISPC_SIZE_LCD );

 
  // Set initial power level

  // Apply display configuration
  __raw_setl( DISPC_CONTROL_GOLCD, DISPC_CONTROL );

  // start scanning
  __raw_setl( DISPC_CONTROL_LCDENABLE, DISPC_CONTROL );
//  LcdSleep(20);
  // enable DVI

  GPIO_SetBits( GPIO6_BASE, MBIT10 );
  }

void 
CmtScreenTiOmap3530::DisplayLcdImage() {
  // Apply display configuration
  __raw_writel( DISPC_CONTROL_GOLCD | __raw_readl(DISPC_CONTROL), DISPC_CONTROL );
  
  // wait for configuration to take effect
  while( __raw_readl( DISPC_CONTROL ) & DISPC_CONTROL_GOLCD );
  }
