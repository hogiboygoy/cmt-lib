//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================
#include <Sys/Core/Misc/cmtQueue.h>

uint32
CmtQueueEngine::WaitAndGet() {
  if( Empty() ) WaitGE( 1, 0x10000000 );
  uint32 res = mTail++;
  if( mTail >= mCount ) mTail = 0;
  return res;
  }

void   
CmtQueueEngine::WaitToPut() {
  if( Full() ) WaitLE( mCount - 2, 0x10000000 );
  }

uint32
CmtQueueEngine::WaitAndPut() {
  if( Full() ) WaitLE( mCount - 2, 0x10000000 );
  uint32 res = mHead++;
  if( mHead >= mCount ) mHead = 0;
  return res;
  }

struct CmtQueueEngineSignal {
  CmtQueueEngine *mQueue;
  uint32          mCount;
  uint32          mTime;
  };

uint_8
cmtQueueEngineLESignal( void *ptr ) {
  CmtQueueEngineSignal *signal = (CmtQueueEngineSignal*)ptr;
  return signal->mQueue->Count() <= signal->mCount || cmtCheckTick( signal->mTime );
  }

uint_8
cmtQueueEngineGESignal( void *ptr ) {
  CmtQueueEngineSignal *signal = (CmtQueueEngineSignal*)ptr;
  return signal->mQueue->Count() >= signal->mCount || cmtCheckTick( signal->mTime );
  }

uint_8 
CmtQueueEngine::WaitLE( uint32 count, uint32 timeOut ) {
  CmtQueueEngineSignal signal;
  cmtSetCheckTick( signal.mTime, timeOut );
  signal.mQueue = this;
  signal.mCount = count;
  cmtWaitEvent( cmtQueueEngineLESignal, &signal );
  return cmtCheckTick( signal.mTime ) ? CMTE_TIME_OUT : CMTE_OK;
  }

uint_8 
CmtQueueEngine::WaitGE( uint32 count, uint32 timeOut ) {
  CmtQueueEngineSignal signal;
  cmtSetCheckTick( signal.mTime, timeOut );
  signal.mQueue = this;
  signal.mCount = count;
  cmtWaitEvent( cmtQueueEngineGESignal, &signal );
  return cmtCheckTick( signal.mTime ) ? CMTE_TIME_OUT : CMTE_OK;
  }







CmtQueueUint8::CmtQueueUint8( uint32 size ) :
  mBuf(0),
  mHead(0),
  mTail(0),
  mCount(size) {
    mBuf = new uint8[size];
    if( mBuf == 0 ) mCount = 0;
  }

uint_8 
CmtQueueUint8::Put( uint8 val ) {
  if( !CanPlace() ) return CMTE_FAIL;
  mBuf[mHead++] = val;
  if( mHead >= mCount ) mHead = 0;
  return CMTE_OK;
  }

void   
CmtQueueUint8::WaitAndPut( uint8 val ) {
  if( Count() >= mCount ) WaitLE( mCount - 2, 0x10000000 );
  Put( val );
  }

uint8  
CmtQueueUint8::WaitAndGet() {
  uint8 val;
  if( mHead == mTail ) WaitGE( 1, 0x10000000 );
  val = mBuf[mTail++];
  if( mTail >= mCount ) mTail = 0;
  return val;
  }

uint8  
CmtQueueUint8::Look( uint32 index ) {
  return mBuf[ mTail + index >= mCount ? mTail + index - mCount : mTail + index ];
  }

uint32 
CmtQueueUint8::Count() const {
  if( mHead >= mTail ) return mHead - mTail;
  return mCount + mHead - mTail;
  }

uint_8 
CmtQueueUint8::CanPlace() const {
  return Count() < mCount - 1;
  }

void   
CmtQueueUint8::Clear() {
  mTail = mHead = 0;
  }

struct CmtQueueSignal {
  CmtQueueUint8 *mQueue;
  uint32         mCount;
  uint32         mTime;
  };

uint_8
cmtQueueLESignal( void *ptr ) {
  CmtQueueSignal *signal = (CmtQueueSignal*)ptr;
  return signal->mQueue->Count() <= signal->mCount || cmtCheckTick( signal->mTime );
  }

uint_8
cmtQueueGESignal( void *ptr ) {
  CmtQueueSignal *signal = (CmtQueueSignal*)ptr;
  return signal->mQueue->Count() >= signal->mCount || cmtCheckTick( signal->mTime );
  }

uint_8 
CmtQueueUint8::WaitLE( uint32 count, uint32 timeOut ) {
  CmtQueueSignal signal;
  cmtSetCheckTick( signal.mTime, timeOut );
  signal.mQueue = this;
  signal.mCount = count;
  cmtWaitEvent( cmtQueueLESignal, &signal );
  return cmtCheckTick( signal.mTime ) ? CMTE_TIME_OUT : CMTE_OK;
  }

uint_8 
CmtQueueUint8::WaitGE( uint32 count, uint32 timeOut ) {
  CmtQueueSignal signal;
  cmtSetCheckTick( signal.mTime, timeOut );
  signal.mQueue = this;
  signal.mCount = count;
  cmtWaitEvent( cmtQueueGESignal, &signal );
  return cmtCheckTick( signal.mTime ) ? CMTE_TIME_OUT : CMTE_OK;
  }

