//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================

//ru ������� �������� ������� � ������ �������������
//ru ������������ ����� 3 ���
uint_8 cmtSignalTick( void *ptr )
{
  return cmtTickCount - *(uint32*)ptr < 0x10000000;
}

//ru �������� �������� �������� (�������� 3 ���)
void cmtWaitTick( uint32 tick )
{
  tick += cmtTickCount;
  cmtWaitEvent( cmtSignalTick, &tick );
}

uint_8 cmtSignalFlagTick( void *ptr ) {
  return *(((CmtFlagTick*)ptr)->mFlag) || (cmtCheckTick( ((CmtFlagTick*)ptr)->mTime ));
}

uint_8 cmtWaitFlagOrTick( uint_8 *flag, uint32 tick ) {
  CmtFlagTick ft;
  cmtSetCheckTick( ft.mTime, tick );
  ft.mFlag = flag;
  cmtWaitEvent( cmtSignalFlagTick, &ft );
  return *(ft.mFlag) ? CMTE_OK : CMTE_TIME_OUT;
}

uint_8
cmtSignalCountTick( void *ptr ) {
  return (*(((CmtCountTick*)ptr)->mCount) == 0) || (cmtCheckTick( ((CmtCountTick*)ptr)->mTime ) );
  }

uint_8 
cmtWaitCountOrTick( uint32 *count, uint32 tick ) {
  CmtCountTick ft;
  cmtSetCheckTick( ft.mTime, tick );
  ft.mCount = count;
  cmtWaitEvent( cmtSignalCountTick, &ft );
  return (*(ft.mCount)) == 0 ? CMTE_OK : CMTE_TIME_OUT;
  }

#ifdef CMT_EVENT_UINT32
//! ������ ��������� ����
uint_8
cmtSignalSetBitTime( void *ptr ) {
  return (((*(((CmtBitSignal*)ptr)->mVal)) & (((CmtBitSignal*)ptr)->mMask)) != 0) || (cmtCheckTick( ((CmtBitSignal*)ptr)->mTime ) );
  }

//! ������ ������� ����
uint_8
cmtSignalClearBitTime( void *ptr ) {
  return ((~(*(((CmtBitSignal*)ptr)->mVal)) & (((CmtBitSignal*)ptr)->mMask)) != 0) || (cmtCheckTick( ((CmtBitSignal*)ptr)->mTime ) );
  }
  
CmtBitSignal::CmtBitSignal( uint32 *val, uint32 mask, uint32 out ) :
  mVal(val), mMask(mask) {
    cmtSetCheckTick( mTime, out );
    }  

uint32
cmtWaitSetBitTime( uint32 *val, uint32 mask, uint32 timeOut ) {
  if( (*val & mask) == 0 ) {
    CmtBitSignal signal( val, mask, timeOut );
    cmtWaitEvent( cmtSignalSetBitTime, &signal );
    }
  return *val & mask;
  }

uint32
cmtWaitClearBitTime( uint32 *val, uint32 mask, uint32 timeOut ) {
  if( ((~(*val)) & mask) == 0 ) {
    CmtBitSignal signal( val, mask, timeOut );
    cmtWaitEvent( cmtSignalClearBitTime, &signal );
    }
  return (~(*val)) & mask;
  }
#endif

#ifdef CMT_EVENT_UINT_8
//! ������ ��������� ����
uint_8
cmtSignalSetBit8Time( void *ptr ) {
  return (((*(((CmtBitSignal_8*)ptr)->mVal)) & (((CmtBitSignal_8*)ptr)->mMask)) != 0) || (cmtCheckTick( ((CmtBitSignal_8*)ptr)->mTime ) );
  }

//! ������ ������� ����
uint_8
cmtSignalClearBit8Time( void *ptr ) {
  return ((~(*(((CmtBitSignal_8*)ptr)->mVal)) & (((CmtBitSignal_8*)ptr)->mMask)) != 0) || (cmtCheckTick( ((CmtBitSignal_8*)ptr)->mTime ) );
  }
  
CmtBitSignal_8::CmtBitSignal_8( uint_8 *val, uint_8 mask, uint32 out ) :
  mVal(val), mMask(mask) {
    cmtSetCheckTick( mTime, out );
    }  

uint32
cmtWaitSetBit8Time( uint_8 *val, uint_8 mask, uint32 timeOut ) {
  if( (*val & mask) == 0 ) {
    CmtBitSignal_8 signal( val, mask, timeOut );
    cmtWaitEvent( cmtSignalSetBit8Time, &signal );
    }
  return *val & mask;
  }

uint32
cmtWaitClearBit8Time( uint_8 *val, uint_8 mask, uint_8 timeOut ) {
  if( ((~(*val)) & mask) == 0 ) {
    CmtBitSignal_8 signal( val, mask, timeOut );
    cmtWaitEvent( cmtSignalClearBit8Time, &signal );
    }
  return (~(*val)) & mask;
  }
#endif
  
//����������
#if defined(CMT_LPC1768)

#elif defined(CMT_ATMEGA32)
  #include <Sys/Core/SysTimer/cmtAtMega32.cpp>

#elif defined(CMT_STM32F103CBT6) || defined(CMT_STM32F105VCT6)
  #include <Sys/Core/SysTimer/cmtStm32f10x.cpp>

#elif defined(CMT_TI_OMAP3530)
  #include <Sys/Core/SysTimer/cmtTiOMAP3530.cpp>

#elif defined(CMT_STM8L151K4)
  #include <Sys/Core/SysTimer/cmtStm8l15x.cpp>
  
#elif defined(CMT_QT)
#else
  #error "CMT:No system timer defined for this CPU"
#endif
