//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================

uint32 cmtTickCount;

void
cmtPortSwitchTask() {
  }

void
cmtSysTimerInit() {
  
  }

void 
cmtWaitSetUInt32( uint32 *val ) {
  //cmtWaitEvent( cmtSignalSetUInt32, val );
  }
