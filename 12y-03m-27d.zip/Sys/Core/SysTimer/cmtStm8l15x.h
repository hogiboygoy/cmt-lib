//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================

extern volatile uint32 cmtTickCount;

void cmtInitSysTimer();

