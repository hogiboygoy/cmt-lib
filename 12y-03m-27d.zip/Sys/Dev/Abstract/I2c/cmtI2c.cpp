//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================

CmtI2cSlaveReporter::CmtI2cSlaveReporter(CmtI2cBase *i2c, uint8 index, uint8 addr, uint8 count, uint8 *buf ) : 
  CmtObject(), 
  mI2c(i2c), 
  mIndex(index),
  mCount(count),
  i(count),
  mBuf(buf) {
  mI2c->mSignalSlaveAddr = new CmtSignalUInt8( this, (CmtObjectUInt8Ptr)(&CmtI2cSlaveReporter::OnAddr), mI2c->mSignalSlaveAddr );
  mI2c->mSignalTransmitByte = new CmtSignalPUInt8( this, (CmtObjectPUInt8Ptr)(&CmtI2cSlaveReporter::OnTransmit), mI2c->mSignalTransmitByte );
  mI2c->mSignalError = new CmtSignalUInt8( this, (CmtObjectUInt8Ptr)(&CmtI2cSlaveReporter::OnError), mI2c->mSignalError );
  mI2c->SetupSlaveAddr( index, addr );
  }

void
CmtI2cSlaveReporter::OnAddr(uint8 index) {
  if( index == mIndex ) i = 0;
  else i = mCount;
  }

void
CmtI2cSlaveReporter::OnTransmit(uint8 *ptr) {
  if( i < mCount ) 
    *ptr = mBuf[i++]; 
  if( i == mCount && mSignalTransmitComplete ) 
    mSignalTransmitComplete->Signal(); 
  }

void
CmtI2cSlaveReporter::OnError(uint8) {
  i = mCount;
  }

//���������� ����������
#ifdef CMT_STM32F105VCT6
  #include <Sys/Dev/Abstract/I2c/cmtSTM32F10x.cpp>
  #include <Sys/Dev/Abstract/I2c/cmtSTM32F105.cpp>
#endif

#ifdef CMT_STM32F103CBT6
  #include <Sys/Dev/Abstract/I2c/cmtSTM32F10x.cpp>
  #include <Sys/Dev/Abstract/I2c/cmtSTM32F103.cpp>
#endif

#ifdef CMT_TI_OMAP3530
  #include <Sys/Dev/Abstract/I2c/cmtTiOmap3530.cpp>
#endif

#ifdef CMT_STM8L151K4
  #include <Sys/Dev/Abstract/I2c/cmtStm8l15x.cpp>
#endif

