//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
//==============================================================================

#ifdef CMT_STM32F105VCT6_LIB0
  #include <Usart/cmtUsartSTM32F105VCT6_LIB0.cpp>
#endif
