//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
// Contens
//   UART/IrDA/CIR
//==============================================================================
#ifndef TI_UART_H
#define TI_UART_H

#define UART1_BASE 0x4806A000
#define UART2_BASE 0x4806C000
#define UART3_BASE 0x49020000
 
#endif

