//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
// Contens
//   Interconnect
//==============================================================================
#ifndef TI_INTERCONNECT_H
#define TI_INTERCONNECT_H

#endif

