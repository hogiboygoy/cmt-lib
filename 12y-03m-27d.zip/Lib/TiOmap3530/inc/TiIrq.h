//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
// Contens
//   Interrupt Controller
//==============================================================================
#ifndef TI_IRQ_H
#define TI_IRQ_H

#endif

