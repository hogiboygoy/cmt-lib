//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
// Contens
//   Multichannel Bufferd Serial Port
//==============================================================================
#ifndef TI_Mbsp_H
#define TI_Mbsp_H

#define McBSP1_BASE 0x48074000
#define McBSP2_BASE 0x49022000
#define McBSP3_BASE 0x49024000
#define McBSP4_BASE 0x49026000
#define McBSP5_BASE 0x48096000


#endif

