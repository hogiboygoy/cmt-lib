//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
// Contens
//   HDQ/1-Wire
//==============================================================================
#ifndef TI_HDQ_H
#define TI_HDQ_H

#define HDQ_BASE 0x480B2000

#endif

