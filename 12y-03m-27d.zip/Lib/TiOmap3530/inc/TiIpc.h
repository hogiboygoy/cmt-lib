//==============================================================================
//              Cooperative MultiTasking system
//                    CMT system
// By Alexander Sibilev
// Contens
//   Interprocessor Communication
//==============================================================================
#ifndef TI_IPC_H
#define TI_IPC_H

#endif

